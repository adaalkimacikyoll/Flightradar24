
  # Flight Radar Design Main

  This is a code bundle for Flight Radar Design Main. The original project is available at https://www.figma.com/design/PINyLy9QkCGdtMyqXV9p80/Flight-Radar-Design-Main.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  